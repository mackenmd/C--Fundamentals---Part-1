﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Generics
{
    class Rabbit : IAmMagical
    {
        public string Name { get; set; }

        public void Dissapear()
        {
            // ...
        }
    }
}
