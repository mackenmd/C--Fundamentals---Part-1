﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Generics
{
    class Balloon : IAmMagical
    {
        public void Dissapear()
        {
            // ...
        }
    }
}
