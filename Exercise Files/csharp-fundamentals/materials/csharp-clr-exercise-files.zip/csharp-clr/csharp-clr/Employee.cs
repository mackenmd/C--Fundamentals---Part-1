namespace csharp_clr
{
    public class Employee
    {
        public string Name { get; set; }
        byte[] _state = new byte[60000];
    }
}